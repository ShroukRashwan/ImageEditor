import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.WritableRaster;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;



/**
 * @author ShroukRashwan
 *
 */

class ImageController extends Canvas {
	
	Image original;
	Shape selectedArea;
	BufferedImage bufferedImage;
	BufferedImage edited;
	BufferedImage cropedPart;
	BufferedImage cropedEdited;
	Dimension screenDimension; 
	MediaTracker trackImageLoading; 
	boolean isReadyToSave;
	boolean isImageLoaded;
	boolean isInverted;
	boolean isBlured;
	boolean isChanged;
	boolean isRectangularCrop;
	boolean isCircularCrop;
	String imagePath;
	float angle, brightnessLevel;
	int centerX, centerY;	
	Point startDrag, endDrag;
	
	//dashed line
	final static float dash1[] = { 10.0f };
	final static BasicStroke dashed = new BasicStroke(3.0f,BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
	
	public ImageController(EditImage frame)
	{
	   screenDimension=getToolkit().getScreenSize(); //get the screen size   
	   centerX=(int)screenDimension.getWidth()/2; //half of the screen width
	   centerY=(int)screenDimension.getHeight()/2;//half of the screen height
	   
	   final EditImage mainFrame = frame;
	   
	   /* Selecting Area Code */
	   this.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				startDrag = new Point(e.getX(), e.getY());
                endDrag = startDrag;
                repaint();
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				if(endDrag!=null && startDrag!=null) {
                    try {
                    	selectedArea = makeRectangle(startDrag.x, startDrag.y, e.getX(), e.getY());
                        mainFrame.updateSelectedRegion(bufferedImage.getSubimage(startDrag.x, startDrag.y, e.getX()-startDrag.x, e.getY()-startDrag.y));   
                        startDrag = null;
                        endDrag = null;
                        repaint();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }   
                }
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
	   
	   
	   this.addMouseMotionListener(new MouseMotionAdapter() {
           public void mouseDragged(MouseEvent e) {
               endDrag = new Point(e.getX(), e.getY());
               repaint();
           }   
       });
	}
		
	public boolean isRectangularCrop() {
		return isRectangularCrop;
	}

	public void setRectangularCrop(boolean isCircularCrop) {
		this.isRectangularCrop = isCircularCrop;
	}

	public boolean isCircularCrop() {
		return isCircularCrop;
	}

	public void setCircularCrop(boolean isCircularCrop) {
		this.isCircularCrop = isCircularCrop;
	}

	public boolean isImageLoaded() {
		return isImageLoaded;
	}

	public void setImageLoaded(boolean isImageLoaded) {
		this.isImageLoaded = isImageLoaded;
	}

	public boolean isInverted() {
		return isInverted;
	}

	public void setInverted(boolean isInverted) {
		this.isInverted = isInverted;
	}

	public boolean isBlured() {
		return isBlured;
	}

	public void setBlured(boolean isBlured) {
		this.isBlured = isBlured;
	}

	public boolean isChanged() {
		return isChanged;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}
	
    public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	
	public float getBrightnessLevel() {
		return brightnessLevel;
	}

	public void setBrightnessLevel(float brightnessLevel) {
		this.brightnessLevel = brightnessLevel;
	}

	public void initialize()
    {
    	isImageLoaded=false; 
    	isInverted=false;
    	isBlured=false;
    	isChanged=false;
    	isCircularCrop= false;
    	isRectangularCrop = false;
    	angle=0.0f;
    	brightnessLevel=0.0f;
    }
	
	private Rectangle2D.Float makeRectangle(int x1, int y1, int x2, int y2) {
		
	       return new Rectangle2D.Float(Math.min(x1, x2), Math.min(y1, y2),
	               Math.abs(x1 - x2), Math.abs(y1 - y2));
	   }
    
	public void paint(Graphics g)
	{
		Graphics2D g2d=(Graphics2D)g; //create Graphics2D object  
		
		if(isImageLoaded)
	    {
			int x=centerX-bufferedImage.getWidth()/2;
		    int y=centerY-bufferedImage.getHeight()/2;
		    //draw the update image
		    if(isBlured || isInverted ||isChanged)
		    {
//		    	edited = replaceInsideBufferedImage(bufferedImage, cropedPart, cropedEdited);
//		    	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);		            
//	            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.9f));
//	            g2d.setPaint(Color.BLACK);
//                g2d.setStroke(dashed);
//                g2d.draw(selectedArea);
			    g2d.translate(x,y);  
			    g2d.drawImage(edited,0,0,null); 
	     
		    }	    
		    else 
		    { 		    	
		    	if (isRectangularCrop)
		    	{
		        				    		
		    		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);		            
		            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.9f));
		            
		    		if (selectedArea != null) 
		    		{
		                g2d.setPaint(Color.BLACK);
		                g2d.setStroke(dashed);
		                g2d.draw(selectedArea);
     	                cropedPart = bufferedImage.getSubimage(selectedArea.getBounds().x-x,selectedArea.getBounds().y-y,selectedArea.getBounds().width,selectedArea.getBounds().height);
     	                //bufferedImage.getGraphics().drawImage(cropedPart, x, y, null);    		
		    		}
		    		
		    		if (startDrag != null && endDrag != null) 
		    		{
		                g2d.setPaint(Color.LIGHT_GRAY);
		                Shape r = makeRectangle(startDrag.x, startDrag.y, endDrag.x,
		                        endDrag.y);
		                g2d.draw(r);
		            }
		    		
				    g2d.translate(x,y); //move to  coordinate (x,y)
				    g2d.drawImage(bufferedImage,0,0,null); //draw image
		    	}
		    	else if (isCircularCrop)
		    	{
		    		
		    		
		    	}
		    	else //draw the original image
		    	{
			
				     g2d.translate(x,y); //move to  coordinate (x,y)
				     g2d.drawImage(bufferedImage,0,0,null); //draw image
		    	}
		     }
	   }
	    g2d.dispose(); //clean the Graphic2D object
		
	}
	   
	public void prepareImage(String imagePath)
    {
	   initialize();
	   try{
		   //track the image loading
		   trackImageLoading = new MediaTracker(this);    
		   original = Toolkit.getDefaultToolkit().getImage(imagePath); 
		   trackImageLoading.addImage(original,0);
		   trackImageLoading.waitForID(0); 
		   //get the image width and height  
		   int width = original.getWidth(null);
		   int height = original.getHeight(null);
		   //create buffered image from the image so any change to the image can be made
		   bufferedImage = createBufferedImageFromImage(original,width,height,false);
		   //create the blank buffered image
		   //the update image data is stored in the buffered image   
		   edited = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);  
		   isImageLoaded = true; //now the image is loaded
	   }
	   catch(Exception e){
		   System.exit(-1);
		   }
	}
	
	public BufferedImage createBufferedImageFromImage(Image image, int width, int height, boolean tran)
	{ 
	 	BufferedImage dest ;
	 	if(tran) 
	 	     dest = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
	 	else
	 	 dest = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	 	
	 	Graphics2D g2 = dest.createGraphics();
	 	g2.drawImage(image, 0, 0, null);
	 	g2.dispose();
	 	return dest;
	}
	
	public void makeImageRotate(BufferedImage image,int w,int h)
	{
	  
	  BufferedImage temp=(BufferedImage)createImage(w,h);
	  Graphics2D  g2d=(Graphics2D)temp.createGraphics(); 
	  angle=(float)Math.PI;   
	  g2d.translate(w/2,h/2); 
	  g2d.rotate(angle); 
	  g2d.translate(-h/2,-w/2); 
	  g2d.drawImage(image,0,0,null); 
	  cropedPart=temp;
	  g2d.dispose();    
	   
	}

	public void invertImage()
	{
	    BufferedImage tempImage;
	    if( isBlured || isChanged )
	    {
	    	tempImage= cropedEdited;     
	    }
	    else
	    {
	    	tempImage= cropedPart;
	    }
	    makeImageRotate(tempImage,tempImage.getHeight(),tempImage.getWidth());
	        
	    isInverted=true; 
	    repaint();     
	 }

	//testing combining 2 imags
	public static BufferedImage replaceInsideBufferedImage(BufferedImage containingImage, BufferedImage toBeReplaced, BufferedImage replaceWithThis) {
	    BufferedImage returnImage = deepCopyImage(containingImage);
	    for (int x = 0; x+toBeReplaced.getWidth() < containingImage.getWidth(); x++) {
	        for (int y = 0; y+toBeReplaced.getHeight() < containingImage.getHeight(); y++) {
	            BufferedImage subImg = containingImage.getSubimage(x, y, toBeReplaced.getWidth(), toBeReplaced.getHeight());
	            if (imageEquals(subImg,toBeReplaced)) {
	                for (int sx = 0; sx < replaceWithThis.getWidth(); sx++) {
	                    for (int sy = 0; sy < replaceWithThis.getHeight(); sy++) {
	                        returnImage.setRGB(x+sx, y+sy, replaceWithThis.getRGB(sx, sy));
	                    }
	                }
	            }
	        }
	    }
	    return returnImage;
	}
	
	// http://stackoverflow.com/a/3514297/1850609
    public static BufferedImage deepCopyImage(BufferedImage bi) {
        ColorModel cm = bi.getColorModel();
        boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
        WritableRaster raster = bi.copyData(null);
        return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
    }

    // http://stackoverflow.com/a/11006474/1850609
    private static boolean imageEquals(BufferedImage image1, BufferedImage image2) {
        int width;
        int height;
        boolean imagesEqual = true;
        if( image1.getWidth()  == ( width  = image2.getWidth() ) && 
            image1.getHeight() == ( height = image2.getHeight() ) ){
            for(int x = 0;imagesEqual == true && x < width; x++){
                for(int y = 0;imagesEqual == true && y < height; y++){
                    if( image1.getRGB(x, y) != image2.getRGB(x, y) ){
                        imagesEqual = false;
                    }
                }
            }
        }else{
            imagesEqual = false;
        }
        return imagesEqual;
    }
    
    
   public void filterImage()
   {
	    float[] elements = {0.0f, 1.0f, 0.0f, -1.0f,brightnessLevel,1.0f,0.0f,0.0f,0.0f}; 
	    Kernel kernel = new Kernel(3, 3, elements);  
	    ConvolveOp cop = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null); 
	    //the kernel
	    edited= new BufferedImage(bufferedImage.getWidth(),bufferedImage.getHeight(),BufferedImage.TYPE_INT_RGB);
	    cop.filter(bufferedImage,edited); 
   }
}


public class EditImage extends JFrame implements ActionListener{

	JFileChooser filechooser;
	// Toolbar & its icons
	JMenuBar toolbar;
	JMenu edit;
	JMenu crop;
	JMenu imageFile;
	
	// Edit Menu Items
	JMenuItem brightness;
	JMenuItem invert;
	JMenuItem blur;
	
	// Image Menu Items
	JMenuItem uploadImage;
	JMenuItem saveImage;
	
	// Crop Menu Items
	JMenuItem circular;
	JMenuItem rectangular;
	
	private JPanel selectedAreaPanel;
	
	String imagePath;
	
	// create instance of Image Controller
	ImageController controller;
	// create container to add image into window
	Container cont = new Container();
	
	public EditImage()
	{
		controller = new ImageController(this);
		
		// create container to add image into window
		Container imageContainer = getContentPane();
		imageContainer.add(controller, BorderLayout.CENTER);
		
		// toolbar
		toolbar = new JMenuBar();
		
		//Init imageFile Menu
		imageFile = new JMenu("Image File");
		uploadImage = new JMenuItem("Upload Image");
		uploadImage.addActionListener(this);
		saveImage = new JMenuItem("Save Image");
		saveImage.addActionListener(this);
		
		imageFile.add(uploadImage);
		imageFile.add(saveImage);
		
		//Init Edit Menu
		edit = new JMenu("Edit Image");
		blur = new JMenuItem("Blur Image");
		blur.addActionListener(this);
		invert = new JMenuItem("Invert Image");
		invert.addActionListener(this);
		brightness = new JMenuItem("Change Image Light Level");
		brightness.addActionListener(this);
		
		edit.add(blur);
		edit.add(invert);
		edit.add(brightness);
		
		//Init Crop Menu
		crop = new JMenu ("Crop Image");
		circular = new JMenuItem("Select Circular Area");
		circular.addActionListener(this);
		rectangular = new JMenuItem("Select Rectangular Area");
		rectangular.addActionListener(this);
		
		crop.add(circular);
		crop.add(rectangular);
		
		// add Menus to toolbar
		toolbar.add(imageFile);
		toolbar.add(crop);
		toolbar.add(edit);
		
		// set toolbar
		setJMenuBar(toolbar);
		
		// set window properties 
		setTitle("Image Editor");
		setExtendedState(this.getExtendedState() | this.MAXIMIZED_BOTH);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		//prepare for uploading image
		filechooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Image files", "jpg", "gif","bmp","png");
		filechooser.setFileFilter(filter);
		filechooser.setMultiSelectionEnabled(false);
		//enableSaving(false);
		controller.requestFocus();
		
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
			new EditImage();
	}
	
	public void getImagePath() {  
		
		int returnVal = filechooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) 		
		{   
			imagePath=filechooser.getSelectedFile().toString();
			controller.prepareImage(imagePath);
		}        
	}
	
	public void getImage()
	{  
		int returnVal = filechooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) 		
		{   
			imagePath=filechooser.getSelectedFile().toString();
			controller.prepareImage(imagePath);
		}        
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		//get action source
		JMenuItem actionSource = (JMenuItem) e.getSource();
		
		if (0 == actionSource.getText().compareTo("Upload Image"))
		{
			getImage();
		    controller.repaint();
		    validate();			
		}
		else if (0 == actionSource.getText().compareTo("Save Image"))
		{
			
		}
		else if (0 == actionSource.getText().compareTo("Blur Image"))
		{
			
		}
		else if (0 == actionSource.getText().compareTo("Invert Image"))
		{
//			if(controller.isImageLoaded())
//			{
//			    controller.invertImage();
//			} 
		}
		else if (0 == actionSource.getText().compareTo("Change Image Light Level"))
		{
			ImageBrightness ib=new ImageBrightness(); 
		    if(controller.isImageLoaded()) {
		     ib.enableSlider(true); 
		     }
		}
		else if (0 == actionSource.getText().compareTo("Select Circular Area"))
		{
			
		}
		else if (0 == actionSource.getText().compareTo("Select Rectangular Area"))
		{
			/* put in generic place and change the drawn shape according to option */
			controller.setRectangularCrop(true);
		}
	}
	
	public void updateSelectedRegion(BufferedImage bufferedImage) {
        Graphics g = selectedAreaPanel.getGraphics();
        g.clearRect(0, 0, 221, 289);
        g.drawImage(bufferedImage, 0, 0, null);
    }
	

	
	
public class ImageBrightness extends JFrame implements ChangeListener
{
	JSlider slider;
	 
	ImageBrightness()
	{
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
			     dispose();
			      
			}
		});
		Container cont=getContentPane();  
		slider=new JSlider(-10,10,0); 
		slider.setEnabled(false);
		slider.addChangeListener(this);
		cont.add(slider,BorderLayout.CENTER); 
		slider.setEnabled(true);
		setTitle("Image brightness");
		setPreferredSize(new Dimension(300,100));
		setVisible(true);
		pack();
		enableSlider(false);
	}
	
	public void enableSlider(boolean enabled)
	{
	  slider.setEnabled(enabled);
	}
	
	public void stateChanged(ChangeEvent e)
	{
	   controller.setBrightnessLevel(slider.getValue()/10.0f);
	   controller.setChanged(true);   
	   controller.filterImage();
	   controller.repaint();
	   //enableSaving(true);
	   
	}
}


	
}
